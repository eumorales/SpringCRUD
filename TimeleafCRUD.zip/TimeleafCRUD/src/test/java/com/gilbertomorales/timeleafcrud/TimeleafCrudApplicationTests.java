package com.gilbertomorales.timeleafcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimeleafCrudApplicationTests {

    @Test
    void contextLoads() {
    }

}
