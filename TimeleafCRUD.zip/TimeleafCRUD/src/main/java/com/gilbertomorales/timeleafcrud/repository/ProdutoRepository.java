package com.gilbertomorales.timeleafcrud.repository;

import com.gilbertomorales.timeleafcrud.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProdutoRepository extends JpaRepository<Produto, Integer> {
}
