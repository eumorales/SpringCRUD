package com.gilbertomorales.timeleafcrud.controller;

import com.gilbertomorales.timeleafcrud.model.Produto;
import com.gilbertomorales.timeleafcrud.repository.ProdutoRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/produto")
public class ProdutoController {

    private final ProdutoRepository produtoRepository;

    public ProdutoController(ProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    @GetMapping("/form")
    public String newForm(Model model) {
        model.addAttribute("produto", new Produto());
        return "form";
    }

    @PostMapping("/salvar")
    public @ResponseBody String salvar(@ModelAttribute Produto produto) {
        produtoRepository.save(produto);
        return "Salvo com sucesso";

    }

    @GetMapping("/listar")
    public String listar(Model model) {
        model.addAttribute("produtos", produtoRepository.findAll());
        return "lista";
    }
}

