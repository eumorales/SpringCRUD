package com.gilbertomorales.timeleafcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TimeleafCrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(TimeleafCrudApplication.class, args);
    }

}
